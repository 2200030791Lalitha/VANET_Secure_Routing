# VANET Secure Routing Protocol Implementation

## Overview
This project implements a secure routing protocol for Vehicular Ad Hoc Networks (VANET) with a focus on security, 
using digital signatures and hash functions to prevent common attacks.

## Features
- Simulation of vehicle movement and communication in a VANET environment
- Implementation of secure routing protocol with digital signatures and hash functions
- Attack simulation and detection (Sybil, Black Hole, Replay, Message Tampering)
- Performance metrics and visualization
- User-friendly GUI interface

## Requirements
- Python 3.6+
- Required packages: matplotlib, numpy, pandas, cryptography, tkinter

## Installation
```bash
pip install matplotlib numpy pandas cryptography
```

## Usage
```bash
python vanet_secure_routing.py
```

## Security Features
- Digital signatures for message authentication
- Multiple hash functions for message integrity
- Trust scoring mechanism
- Attack detection algorithms

## Performance Metrics
- Packet Delivery Ratio
- End-to-End Delay
- Throughput
- Security Effectiveness
- Hash Algorithm Performance

## License
This project is for educational purposes only.
